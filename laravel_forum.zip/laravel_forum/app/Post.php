<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    protected $fillable = ([
        'title',
        'category',
        'status',
        'author',
        'views',
        'disable_comment',
        'message',
        'is_pinned'
    ]);
}
