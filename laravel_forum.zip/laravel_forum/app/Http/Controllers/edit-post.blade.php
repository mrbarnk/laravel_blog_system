
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <form action="{{ route('postroute.store') }}" method="post" id="formsend">
        {{ csrf_field() }}
        <label for="inputTitle" class="sr-only">Title</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="{{ old('title') }}" name="title"><br>
        <label for="category" class="sr-only"></label>
        <select name="category" id="" class="form-control" style="height:40px;">
            <option value="1">Tech</option>
            <option value="2">Blogging</option>
            <option value="3">Tutorials</option>
            <option value="4">Bugs Report</option>
            <option value="5">Computer programming</option>
        </select><br>
        <label for="message" class="sr-only">Message</label>
        <textarea id="txtEditor" name="message" cols="30" rows="10" class="form-control">{{ old('message') }}</textarea><br>
        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Create Post</button>
      </form>
    </main>
  