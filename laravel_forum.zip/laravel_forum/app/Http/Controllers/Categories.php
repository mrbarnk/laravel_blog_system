<?php

namespace App\Http\Controllers;

use App\Category;
use App\Post;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Categories extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $allCat = Category::all();
        foreach($allCat as $thisCat){
            $author = User::find($thisCat->added_by);
        }
        return view('categories')->with('cat',$allCat)->with('added_by',$author);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'cat_name'=>'required'
        ]);
        $createCat = Category::create([
            'cat_name'=>$request->input('cat_name'),
            'added_by'=>session()->get('user_id')
        ]);
        if($createCat){
            return back()->with('success','Category successfully added');
        }else{
            return back()->withInput();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category, $id)
    {
        //
        $return = str_replace('-',' ',$id);
        $cat = DB::table('categories')->where('cat_name',$return)->get();
        foreach ($cat as $cats) {
            $thisCatPosts = DB::table('posts')->where('category',$cats->id)->get();
            $postUser = User::find($cats->id);
            $page = Post::paginate();
        }
        // return $thisCatPosts;
        return view('user-posts')->with('posts',$thisCatPosts)->with('post_user',$postUser)->with('paginator',$page);
        // return view('index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category,$id)
    {
        //
        $findCat = Category::find($id);
        if($findCat){
            return view('edit-categories')->with('cats',$findCat);
        }else{
            return back();
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Category $category)
    {
        //
        $request->validate([
            'cat_name'=>'required'
        ]);
        $date = Date('Y-m-d h:i:s');
        $cat_id = substr($request->input('token_'),0,1);
        $findCat = Category::find($cat_id);
        $findCat->cat_name = $request->input('cat_name');
        $findCat->updated_at = $date;
        if($findCat->save()){
            return back()->with('success','Category name updated');
        }else{
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        //
    }
}
