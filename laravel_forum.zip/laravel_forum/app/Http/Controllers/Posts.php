<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\Category;
use App\Comment;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Posts extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function page(Request $request,$id)
    {
        //
        // $posts = DB::table('posts')->join('userss','posts.author','users.id')
        // ->orderBy('users.id','DESC')->get();
        $posts = DB::table('users')->join('posts','users.id','posts.author')
        ->orderBy('posts.id','DESC')->where('status','0')->get();
        //>paginate($request->id)
        // return $posts;
        // $posts = Post::all()->where('users','users.username','posts.author');
        // $row = [];
        // return ($posts);
        // foreach ($posts as $added) {
        //     // ->get()->toArray();
        //     $added_by[] = DB::table('users')->where('id',$added->author)->get()->toArray();
        //     // $adby = array_merge($row,$added_by);
        //     // return ($adby);
        // }
        // $adby = array_merge($pots,$added_by);
         $page = Post::paginate();
         
        return view('index')->with('posts',$posts)->with('paginator',$page);
    }

    public function index()
    {
        //
        // $posts = DB::table('posts')->join('userss','posts.author','users.id')
        // ->orderBy('users.id','DESC')->get();
        $posts = DB::table('users')->join('posts','users.id','posts.author')
        ->orderBy('posts.id','DESC')->where('status','0')->paginate(20);
        $cats = Category::all();
        // return $posts;
        // $posts = Post::all()->where('users','users.username','posts.author');
        // $row = [];
        // return ($posts);
        // foreach ($posts as $added) {
        //     // ->get()->toArray();
        //     $added_by[] = DB::table('users')->where('id',$added->author)->get()->toArray();
        //     // $adby = array_merge($row,$added_by);
        //     // return ($adby);
        // }
        // $adby = array_merge($pots,$added_by);$page = Post::paginate();
        $page = Post::paginate();
        return view('index')->with('posts',$posts)->with('paginator',$page)->with('cats',$cats);
        // return view('index')->with('posts',$posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title'=>'required',
            'category'=>'required',
            'message'=>'required|min:20'
        ]);
        $createPost = Post::create([
            'title'=>$request->input('title'),
            'category'=>$request->input('category'),
            'message'=>$request->input('message'),
            'status'=>$request->input('status'),
            'author'=>session()->get('user_id'),
            'views'=>'0',
            'is_pinned'=>$request->input('is_pinned'),
            'disable_comment'=>$request->input('dissable_comment'),
            'is_pinned'=>'no'
        ]);
        if($createPost){
            return back()->with('success','Post submitted successflly');
        }
        // 'title',
        // 'category',
        // 'status',
        // 'disable_comment',
        // 'message'
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post, Request $request)
    {
        //
        $thisPost = Post::find($request->id);
        $postCat = Category::find($thisPost->category);
        $postUser = User::find($thisPost->author);
        $comment = DB::table('users')->where('post_id',$request->id)->where('status','0')->join('comments','comments.user_id','users.id')->get();
        $page = Post::paginate();
        $recentPosts = DB::table('posts')->latest()->limit(5)->get();
        $popular = DB::table('posts')->orderBy('views','DESC')->limit(5)->get();
        DB::update("update posts set views=? where id=?",array($thisPost->views+1,$thisPost->id));
        return view('post')->with('post',$thisPost)->with('cat',$postCat)->with('post_user',$postUser)->with('comment',$comment)->with('paginator',$page)->with('recent',$recentPosts)->with('popular',$popular);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post, Request $request)
    {
        //
        $findPost = Post::find($request->id);
        // return $findPost;
        if($findPost){
            if($findPost->author == session()->get('user_id') || session()->get('user_role')== 7){
            $post = Post::find($request->id);
            $thiscat = Category::find($post->category);
            $cat = Category::all();
            return view('edit-post')->with('post',$post)->with('cat',$cat)->with('postcat',$thiscat);
            }
            else{
                return back()->with('failure','You don\'t have enough permission to edit that post.');
            }
        }
        else{
            return 404;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
        //
        $request->validate([
            'title'=>'required',
            'category'=>'required',
            'message'=>'required|min:20'
        ]);
        $cat_id = substr($request->input('token_'),0,1);
        $thisPost = Post::find($cat_id);
        if(session()->get('user_role') == 7){
            $thisPost->title = $request->input('title');
            $thisPost->category = $request->input('category');
            $thisPost->message = $request->input('message');
            $thisPost->status = $request->input('status');
            $thisPost->disable_comment = $request->input('dissable_comment');
            $thisPost->is_pinned = $request->input('is_pinned');
        }else {
            $thisPost->title = $request->input('title');
            $thisPost->category = $request->input('category');
            $thisPost->message = $request->input('message');
            $thisPost->status = $request->input('status');
        }
        if($thisPost->save()){
            return back()->with('success','Post updated successfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        //
    }
    public function new_post()
    {
        
        $cat = Category::all();
        return view('new-post')->with('cat',$cat);
    }
}
