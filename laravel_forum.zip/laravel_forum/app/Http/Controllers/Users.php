<?php

namespace App\Http\Controllers;

use App\User;
use App\Post;
use App\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Users extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(session()->get('user_role') == 7){
            $allUsers = User::all();
            return view('users')->with('users',$allUsers);
        }else {
            $findUser = User::find(session()->get('user_id'));
            if($findUser){
                return view('edit-user')->with('user',$findUser);
            }
            else {
                return redirect()->intended('/');
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'username'=>'required|alpha|unique:users',
            'email'=>'required|email|unique:users',
            'password'=>'required'
        ]);
        $email_verified_at = date('y-m-d h:i:s');
        $user_role = 1;
        $email_verification_token = uniqid('.',true);
        $pass = Hash::make($request->input('password'));
        $CreateUser = User::create([
            'username'=>$request->input('username'),
            'email'=>$request->input('email'),
            'password'=>$pass,
            'email_verification_token'=>$email_verification_token,
            'email_verified_at'=>$email_verified_at,
            'user_role'=>$user_role,
            'is_verified'=>'1'
        ]);
        if($CreateUser){
            return redirect()->intended('')->with('success',$request->username.' registered successfully!');
        }else {
            return back()->with('failure',$request->username.' registeration failed!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
        $thisPost = DB::table('posts')->where('author',$user->id)->where('status','0')->get();
        $thisPosts = DB::table('posts')->where('author',$user->id);
        $postUser = User::find($user->id);
        return view('user-posts')->with('posts',$thisPost)->with('post_user',$postUser);
    }
    public function showUserPost(Request $request)
    {
        //
        $users = DB::table('users')->where('username',$request->name)->get();
        foreach ($users as $user) {
            $thisPost = DB::table('posts')->where('author',$user->id)->where('status','0')->limit(20)->get();
            $thisPosts = DB::table('posts')->where('author',$user->id);
            $postUser = User::find($user->id);
            $page = Post::paginate();
        }
        return view('user-posts')->with('posts',$thisPost)->with('post_user',$postUser)->with('paginator',$page);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        //
        if(session()->has('user_role')){
            if(session()->get('user_role') == 7){
                $findUser = User::find($user->id);
                if($findUser){
                    return view('edit-user')->with('user',$findUser);
                }else{
                    return back();
                }
            }else {
                return redirect()->intended('/');
            }
        }else {
            return redirect()->intended('/');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
        $request->validate([
            'username'=>'required|alpha',
            'email'=>'required'
        ]);
        $date = Date('Y-m-d h:i:s');
        $thisUser = User::find($user->id);
        $thisUser->username = $request->input('username');
        $thisUser->email = $request->input('email');
        if(session()->get('user_role') == 7){
            $thisUser->user_role = $request->input('user_role');
        }
        $thisUser->updated_at = $date;
        if($thisUser->save()){
            return back()->with('success','User\'s updated');
        }else{
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }
    public function login(Request $request, User $user)
    {
        $request->validate([
            'username'=>'required|alpha',
            'password'=>'required'
        ]);
        $datas = $request->only('username','password');
        if(Auth::attempt($datas)){
            $return = DB::table('users')->where('username',$request->input('username'))->first();
            // foreach($return as $data){
                // echo $return->user_role;
                $request->session()->put('user_id',$return->id);
                $request->session()->put('username',$request->username);
                $request->session()->put('user_role',$return->user_role);
            // }
            return back();
        }
        // echo 'not correct';
        return back()->withInput()->with('log_failure','Credentials not correct');
    }
    public function logout()
    {
        session()->flush();
        return back();
    }
}
