@include ('admin.header')
@include ('admin.posts')
@include ('admin.footer')