@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <form action="{{ route('cat.store') }}" method="post" id="formsend">
        {{ csrf_field() }}
        <label for="cat_name" class="sr-only">Category name</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="{{ old('title') }}" name="cat_name"><br>
        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Create Category</button>
      </form><br>
      <div class="panel panel-default">
      <!-- Default panel contents -->
      <div class="panel-heading">Categories</div>

      <!-- Table -->
      <table class="table">
        <thead>
          <tr>
            <!-- <th>#</th> -->
            <th>Category title</th>
            <th>Added by</th>
            <th colspan="2">Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach($cat as $cats)
          <tr>
            <td>{{ $cats->cat_name }}</td>
            <td>{{ $added_by->username }}</td>
            <td colspan="2"><a href="{{ url('/cat') }}/{{ $cats->id }}/edit" class="btn btn-info">Edit</a>
            <form action="{{ route('cat.destroy',$cats->id) }}" method="post" style="display:inline;">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="DELETE">
                <button type="submit" class="btn btn-danger" title="Delete category">del</button>
            </form>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    </main>
@include ('layout.footer')