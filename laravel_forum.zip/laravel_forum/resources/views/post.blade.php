@include ('layout.header')
@include ('layout.head-nav')
@include ('layout.post')
@include ('layout.footer')

