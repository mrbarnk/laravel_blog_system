@include ('layout.header')
@include ('layout.register')
@include ('layout.footer')