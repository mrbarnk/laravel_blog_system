@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <form action="{{ route('postroute.update',$post->id) }}" method="post" id="formsend">
        {{ csrf_field() }}
        <input type="hidden" name="_method" value="PUT">
        <label for="inputTitle" class="sr-only">Title</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="{{ $post->title }}" name="title"><br>
        <input type="hidden" name="token_" value="{{ $post->id }} <?php echo uniqid('',true).rand(0,20);?>">
        <label for="category" class="sr-only"></label>
        <select name="status" id="" class="form-control" style="height:40px;">
            <option value="0" selected>Visible</option>
            <option value="1">Draft(will not be in news feed)</option>
        </select><br>

        <label for="category" class="sr-only"></label>
        <select name="category" id="" class="form-control" style="height:40px;">
            <option value="{{ $post->category }}" selected>{{ $postcat->cat_name }}</option>
        @foreach($cat as $cats)
            <option value="{{ $cats->id }}">{{ $cats->cat_name }}</option>
        @endforeach
        </select><br>
        <label for="message" class="sr-only">Message</label>
        <textarea id="txtEditor" name="message" cols="30" rows="10" class="form-control">{{ $post->message }}</textarea><br>

        @if(session()->get('user_role') == 7)
        <p>Pin To Homepage</p>
        <select name="is_pinned" id="" class="form-control" style="height:40px;">
            <option value="yes">Yes</option>
            <option value="no">No</option>
        </select><br>
        <p>Dissable comment</p>
        <select name="dissable_comment" id="" class="form-control" style="height:40px;">
            <option value="yes">Yes</option>
            <option value="no">No</option>
        </select><br>
        @endif

        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update Post</button>
      </form>
    </main>
  
@include ('layout.footer')