@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <form action="{{ route('user.update',$user->id) }}" method="post" id="formsend">
        {{ csrf_field() }}
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="token_" value="{{ $user->id }}<?php echo uniqid().rand(0,10); ?>">
        <label for="username" class="sr-only">Username</label>
        <input type="text" id="inputUser" class="form-control" placeholder="Username" autofocus value="{{ $user->username }}" name="username"><br>
        <label for="username" class="sr-only">Email</label>
        <input type="text" id="inputUser" class="form-control" placeholder="Email" autofocus value="{{ $user->email }}" name="email"><br>
        @if(session()->get('user_role') == 7)
        <label for="username" class="sr-only">User role</label>
        <select name="user_role" id="" class="form-control" style="height: 40px;">
            <?php
            if($user->user_role == 1){
                $role_name = 'Unverified';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 0){
                $role_name = 'User';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 2){
                $role_name = 'Banned';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 7){
                $role_name = 'Admin';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }
             ?>
            <option value="2">Banned</option>
            <option value="0">User</option>
            <option value="7">Admin</option>
        </select><br>
        @endif

        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update!</button>
      </form>
      <hr class="clearfix">
      <form action="" method="post">
      <h3>Send mail <span class="text-danger">(not yet added)</span> </h3>
      <hr>
      <textarea name="sendmail" id="" cols="30" rows="10" placeholder="Send mail" class="form-control"></textarea><br>
      <button type="submit" class="btn btn-primary">Send mail</button>
      </form>
    </main>
@include ('layout.footer')