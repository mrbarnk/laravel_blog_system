@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <form action="{{ route('cat.update',$cats->id) }}" method="post" id="formsend">
        {{ csrf_field() }}
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="token_" value="{{ $cats->id }}<?php echo uniqid().rand(0,10); ?>">
        <label for="cat_name" class="sr-only">Category name</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="{{ $cats->cat_name }}" name="cat_name"><br>
        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update Category</button>
      </form>
    </main>
@include ('layout.footer')