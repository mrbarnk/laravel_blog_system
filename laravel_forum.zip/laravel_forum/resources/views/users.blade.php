@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <div class="panel panel-default">
      <!-- Default panel contents -->
      <div class="panel-heading">Users</div>

      <!-- Table -->
      <table class="table">
        <thead>
          <tr>
            <!-- <th>#</th> -->
            <th>Username</th>
            <th>Email</th>
            <th>Join date</th>
            <th colspan="2">Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach($users as $user)
          <tr>
            <td>{{ $user->username }}</td>
            <td>{{ $user->email }}</td>
            <td>{{ $user->created_at }}</td>
            <td colspan="2"><a href="{{ url('/user') }}/{{ $user->id }}/edit" class="btn btn-info">Edit</a>
                <a href="{{ url('/view') }}/{{ $user->id }}" class="btn btn-danger" title="View Users posts">Visit profile</button>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    </main>
@include ('layout.footer')