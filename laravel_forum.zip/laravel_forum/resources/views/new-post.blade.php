@include ('layout.header')
@include ('layout.head-nav')
@include ('layout.new-post')
@include ('layout.footer')