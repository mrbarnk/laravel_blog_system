@include ('admin.header')
@include ('admin.index')
@include ('admin.footer')