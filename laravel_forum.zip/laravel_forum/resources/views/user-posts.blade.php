@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    @foreach($posts as $post)
    <div class="col-sm-12">
    @endforeach
    <a href="{{ url('/user') }}/{{ $post->author }}/edit" class="btn btn-info">Edit account</a>
    </div><br>
    <div class="col-sm-8 text-center" style="">
    @if($errors->any())
      @foreach($errors->all() as $error)
      <p class="alert alert-danger">{{ $error }}</p>
      @endforeach
    @endif
    @if(session()->has('failure'))
      <p class="alert alert-danger">{{ session()->get('failure') }}</p>
    @endif
    </div>

      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <table class="table">
        <thead class="thead-light">
          <tr>
            <th scope="col">Topic</th>
            <th scope="col">Created</th>
            <th scope="col">Statistic</th>
            <th>Last post</th>
          </tr>
        </thead>
        <tbody>
        @foreach($posts as $post)
        <?php $safeUrl = strtolower(str_replace(' ','-',$post->title)); ?>
          <tr>
            <td><a href="{{ url('/t') }}/{{ $post->id.'/'.$safeUrl }}"> <span class="btn btn-info"><i class="glyphicon glyphicon-pushpin"></i> </span> {{ $post->title }}</a></td>
            <td>by <a href="{{ url('/') }}/u/{{ $post_user->username }}">{{ $post_user->username }}</a><br> {{ $post->created_at }} </td>
            <td><!--5 replies--><i class="glyphicon glyphicon-eye-open"></i> <br />{{ $post->views }} views</td>
            <td>by <a href="{{ url('/') }}/u/{{ $post_user->username }}">{{ $post_user->username }}</a><br />{{ $post->created_at }}</td>
          </tr>
        @endforeach
        </tbody>
      </table>
      <hr>
                @if ($paginator->hasPages())
                <ul class="pagination" role="navigation">
                    {{-- Previous Page Link --}}
                    @if ($paginator->onFirstPage())
                        <li class="disabled" aria-disabled="true"><span>@lang('pagination.previous')</span></li>
                    @else
                        <li><a href="{{ $paginator->previousPageUrl() }}" rel="prev">@lang('pagination.previous')</a></li>
                    @endif

                    {{-- Next Page Link --}}
                    @if ($paginator->hasMorePages())
                        <li><a href="{{ $paginator->nextPageUrl() }}" rel="next">@lang('pagination.next')</a></li>
                    @else
                        <li class="disabled" aria-disabled="true"><span>@lang('pagination.next')</span></li>
                    @endif
                </ul>
            @endif
    </main>
@include ('layout.footer')