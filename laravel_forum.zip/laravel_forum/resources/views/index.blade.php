@include ('layout.header')
@include ('layout.head-nav')
@include ('layout.main')
@include ('layout.footer')