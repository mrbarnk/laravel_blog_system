@include ('layout.header')
@include ('layout.head-nav')
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <form action="{{ route('comment.update',$comment->id) }}" method="post" id="formsend">
        {{ csrf_field() }}
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="token_" value="{{ $comment->id }} <?php echo uniqid('',true).rand(0,20);?>">
        <label for="category" class="sr-only"></label>
        <select name="status" id="" class="form-control" style="height:40px;">
            <option value="0" selected>Visible</option>
            <option value="1">Draft(will not be in news feed)</option>
        </select><br>
        <label for="message" class="sr-only">Message</label>
        <textarea id="txtEditor" name="message" cols="30" rows="10" class="form-control">{{ $comment->comment }}</textarea><br>

        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update Post</button>
      </form>
    </main>
  
@include ('layout.footer')