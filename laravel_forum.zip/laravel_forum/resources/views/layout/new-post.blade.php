
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- @yield('alert') -->
    @if($errors->any())
        @foreach($errors->all() as $error)
        <p class="alert alert-danger"><strong>Failure!!!</strong> {{ $error }}</p>
        @endforeach
    @elseif(session()->has('success'))
        <p class="alert alert-success"><strong>Success!!!</strong> {{ session()->get('success') }}</p>
    @endif
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    @include('layout.form')
      <form action="{{ route('postroute.store') }}" method="post" id="formsend">
        {{ csrf_field() }}
        <label for="inputTitle" class="sr-only">Title</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="{{ old('title') }}" name="title"><br>
        <label for="category" class="sr-only"></label>
        <select name="status" id="" class="form-control" style="height:40px;">
            <option value="0" selected>Visible</option>
            <option value="1">Draft(will not be in news feed)</option>
        </select><br>
        <label for="category" class="sr-only"></label>
        <select name="category" id="" class="form-control" style="height:40px;">
        @foreach($cat as $cats)
            <option value="{{ $cats->id }}">{{ $cats->cat_name }}</option>
        @endforeach
        </select><br>
        <label for="message" class="sr-only">Message</label>
        <textarea id="txtEditor" name="message" cols="30" rows="10" class="form-control">{{ old('message') }}</textarea><br>
        <!-- <input type="text" class="form-control"><br> -->
        @if(session()->get('user_role') == 7)
        <p>Pin To Homepage</p>
        <select name="is_pinned" id="" class="form-control" style="height:40px;">
            <option value="no">No</option>
            <option value="yes">Yes</option>
        </select><br>
        <p>Dissable comment</p>
        <select name="dissable_comment" id="" class="form-control" style="height:40px;">
            <option value="no">No</option>
            <option value="yes">Yes</option>
        </select><br>
        @endif
        <button type="submit" class="btn btn-primary">Create Post</button>
      </form>
    </main>
  