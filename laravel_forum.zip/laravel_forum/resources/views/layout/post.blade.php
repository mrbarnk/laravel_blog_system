
    <!-- Begin page content -->
    <main role="main" class="container">
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
      <!-- return view('post')->with('post',$thisPost)->with('cat',$postCat)->with('post_user',$postUser); -->
      <table class="table" hidden>
        <thead class="thead-light">
          <tr>
            <th scope="col">Topic</th>
            <th scope="col">Created</th>
            <th scope="col">Statistic</th>
            <th>Last post</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><h4> <span class="btn btn-info"><i class="glyphicon glyphicon-pushpin"></i> </span> {{ $post->title }}</h4><br></td>
            <td>by <a href="#">admin</a><br> 03 Apr 2017, 12:40 </td>
            <td>5 replies<br />173 views</td>
            <td>by <a href="#">Author name</a><br />05 Apr 2017, 22:07</td>
          </tr>
        </tbody>
      </table>
      <section class="col-sm-12">
            <div class="col-sm-8 panel">
            @if(session()->has('failure'))
              <p class="alert alert-danger">{{ session()->get('failure') }}</p>
                @endif
                @if(session()->has('success'))
                  <p class="alert alert-success">{{ session()->get('success') }}</p>
                @endif
                @if($errors->any())
                  @foreach($errors->all() as $error)
                    <p class="alert alert-danger"> {{ $error }} </p>
                  @endforeach
                @endif
              <ol class="breadcrumb">
                <li><a href="{{ url('/') }}">Home</a></li>
                <?php $srurl = str_replace(' ','-',$cat->cat_name); ?>
                <li><a href="{{ url('/c') }}/{{ $srurl }}">{{ $cat->cat_name }}</a></li>
                <li class="active">{{ $post->title }}</li>
            </ol>
                <h4>{{ $post->title }}</h4><hr>
                <p><?php echo $post->message; ?></p>
                <hr>
                <div>
                <form action="{{ route('comment.store') }}" method="POST">
                {{ csrf_field() }}
                    <h4>Comment here</h4>
                    <input type="hidden" name="token__" value="{{ $post->id }}">
                    <textarea id="txtEditor" class="form-control" placeholder="Name" name="comment"></textarea><br>
                    <button type="submit" class="btn btn-info">Comment</button>
                </form>
                    <h4>Comments</h4>
                    <div class="bs-example" data-example-id="media-alignment">
    @foreach($comment as $comments)
    <div class="media">
      <div class="media-left">
        <a href="#">
          <img class="media-object" data-src="holder.js/64x64" alt="64x64" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+PCEtLQpTb3VyY2UgVVJMOiBob2xkZXIuanMvNjR4NjQKQ3JlYXRlZCB3aXRoIEhvbGRlci5qcyAyLjYuMC4KTGVhcm4gbW9yZSBhdCBodHRwOi8vaG9sZGVyanMuY29tCihjKSAyMDEyLTIwMTUgSXZhbiBNYWxvcGluc2t5IC0gaHR0cDovL2ltc2t5LmNvCi0tPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PCFbQ0RBVEFbI2hvbGRlcl8xNjc5ZmFlZTg0OCB0ZXh0IHsgZmlsbDojQUFBQUFBO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1mYW1pbHk6QXJpYWwsIEhlbHZldGljYSwgT3BlbiBTYW5zLCBzYW5zLXNlcmlmLCBtb25vc3BhY2U7Zm9udC1zaXplOjEwcHQgfSBdXT48L3N0eWxlPjwvZGVmcz48ZyBpZD0iaG9sZGVyXzE2NzlmYWVlODQ4Ij48cmVjdCB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIGZpbGw9IiNFRUVFRUUiLz48Zz48dGV4dCB4PSIxMy4xNzk2ODc1IiB5PSIzNi41Ij42NHg2NDwvdGV4dD48L2c+PC9nPjwvc3ZnPg==" data-holder-rendered="true" style="width: 64px; height: 64px;">
        </a>
      </div>
      <div class="media-body">
        <h4 class="media-heading"><a href="{{ url('/') }}/u/{{ $comments->username }}">{{ $comments->username }}</a></h4>
        @if(session()->get('user_role') == 7 || session()->get('user_id') == $comments->user_id)
        <p><a href="{{ url('/comment') }}/{{ $comments->id }}/edit">edit</a></p>
        @endif
        <p><?php echo $comments->comment ?></p>
      </div>
    </div>
    @endforeach
  </div>
                    <hr>
                </div>

            </div>
            <div class="col-sm-4 panel">
                <form action="" method="POST" hidden>
                {{ csrf_field() }}
                    <h4>Subscribe to us</h4><hr>
                    <input type="text" class="form-control" placeholder="Name"><br>
                    <input type="text" class="form-control" placeholder="Email address"><br>
                    <button type="submit" class="btn btn-info">Subscribe</button>
                </form>
                <hr>
                <div>
                    <div class="panel panel-default">
                    <div class="panel-heading">Recent posts</div>
                    @foreach($recent as $recents)
                    <div class="panel-body">
                    <?php $safeUrl = strtolower(str_replace(' ','-',$recents->title)) ?>
                       <a href="{{ url('/') }}/t/{{ $recents->id }}/{{ $safeUrl }}">{{ $recents->title }}</a>
                    </div>
                    @endforeach
                    </div>
                </div>
                <hr>
                <div>
                    <div class="panel panel-default">
                    <div class="panel-heading">Popular posts</div>
                    @foreach($popular as $populars)
                    <div class="panel-body">
                    <?php $safeUrlP = strtolower(str_replace(' ','-',$populars->title)) ?>
                       <a href="{{ url('/') }}/t/{{ $populars->id }}/{{ $safeUrlP }}">{{ $populars->title }}</a>
                    </div>
                    @endforeach
                    </div>
                </div>
            </div>
        </section>
    </main>
  