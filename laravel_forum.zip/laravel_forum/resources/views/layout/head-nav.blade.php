<body>

    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" style="padding-right:10%;padding-left:10%;">
        <a class="navbar-brand" href="{{ url('/') }}">{{ config('app.name') }}</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto hide">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">Disabled</a>
            </li>
          </ul>
          <form action="{{ url('login') }}" method="POST" class="form-inline mt-2 mt-md-0 navbar-right">
          @if(session()->has('username'))
            <a href="{{ url('new-post') }}" class="btn btn-success" type="button"><i class="fa fa-pencil"></i>Create topic</a>&nbsp;
            <button class="btn btn-info" type="button"><i class="fa fa-user"></i> Account({{session()->get('username')}})</button>&nbsp;
            <a href="{{ url('logout') }}" class="btn btn-danger" type="button">Logout</a>
          @endif
          @if(!session()->has('username'))
          {{ csrf_field() }}
            <input class="form-control mr-sm-2" type="text" placeholder="username" aria-label="Username" value="{{ old('username') }}" name="username">
            <input class="form-control mr-sm-2" type="password" placeholder="Password" aria-label="Password" name="password">
            <button class="btn btn-outline-success my-2 my-sm-0 btn-success" type="submit">Login</button>
            &nbsp;<a href="{{ url('/register') }}" class="btn btn-success">Signup</a>
            @endif
          </form>
          <!-- <div class="form-inline mt-2 mt-md-0 navbar-right"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Open modal for @mdo</button></div> -->
        </div>
      </nav>
    </header>
    @if(session()->has('log_failure'))
      <p class="alert alert-danger">{{ session()->get('log_failure') }}</p>
    @endif