
    <footer class="footer">
      <div class="container">
        <span class="text-muted"> Copyright &copy;<?php echo e(date('Y')); ?> made with <i class="glyphicon glyphicon-heart"></i> by <a href="<?php echo e(config('app.author_url')); ?>"><?php echo e(config('app.author_name')); ?></a></span>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- <script src="js/editor.js"></script> -->
    <script type="text/javascript" src="http://code.jquery.com/jquery.min.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?php echo e(url('js/jquery-te-1.4.0.min.js')); ?>" charset="utf-8"></script>

    <script>
    // $("#txtEditor").Editor();
    </script>
    <!-- <script src="js/jquery3.min.js"></script> -->
    <script>
			$(document).ready(function() {
        $('#txtEditor').jqte();
        // let n = $("#txtEditor").val();
        // $("#formsend").submit( function (event) {
        // if($("textarea").val() == ''){
        //   event.preventDefault();
        // }
        // });
        
				
			});
		</script>
  </body>
</html>
