<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.head-nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- <?php echo $__env->yieldContent('alert'); ?> -->
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="alert alert-danger"><strong>Failure!!!</strong> <?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(session()->has('success')): ?>
        <p class="alert alert-success"><strong>Success!!!</strong> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    <?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <form action="<?php echo e(route('user.update',$user->id)); ?>" method="post" id="formsend">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="token_" value="<?php echo e($user->id); ?><?php echo uniqid().rand(0,10); ?>">
        <label for="username" class="sr-only">Username</label>
        <input type="text" id="inputUser" class="form-control" placeholder="Username" autofocus value="<?php echo e($user->username); ?>" name="username"><br>
        <label for="username" class="sr-only">Email</label>
        <input type="text" id="inputUser" class="form-control" placeholder="Email" autofocus value="<?php echo e($user->email); ?>" name="email"><br>
        <?php if(session()->get('user_role') == 7): ?>
        <label for="username" class="sr-only">User role</label>
        <select name="user_role" id="" class="form-control" style="height: 40px;">
            <?php
            if($user->user_role == 1){
                $role_name = 'Unverified';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 0){
                $role_name = 'User';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 2){
                $role_name = 'Banned';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }else if($user->user_role == 7){
                $role_name = 'Admin';
                echo "<option value='".$user->user_role."' selected>$role_name</option>";
            }
             ?>
            <option value="2">Banned</option>
            <option value="0">User</option>
            <option value="7">Admin</option>
        </select><br>
        <?php endif; ?>

        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update!</button>
      </form>
      <hr class="clearfix">
      <form action="" method="post">
      <h3>Send mail <span class="text-danger">(not yet added)</span> </h3>
      <hr>
      <textarea name="sendmail" id="" cols="30" rows="10" placeholder="Send mail" class="form-control"></textarea><br>
      <button type="submit" class="btn btn-primary">Send mail</button>
      </form>
    </main>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>