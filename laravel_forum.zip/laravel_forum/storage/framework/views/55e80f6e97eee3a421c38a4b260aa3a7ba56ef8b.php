<?php $__env->startSection('title'); ?>
    Student Enrollement App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<br class="clearfix" style="clear:both!important;">
<h1>Our Content</h1>

<?php if(session()->has('success')): ?>
   <p class="alert alert-success" role="alert"> <?php echo e(session()->get('success')); ?> </p>
<?php endif; ?>

<div class="col-sm-12">
        <div class="col-sm-6">
        <form action="<?php echo e(route('student.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="text" class="form-control" name="student_name" id="" value="<?php echo e(old('student_name')); ?>"><br>
            <input type="number" class="form-control" name="student_role" id="" value="<?php echo e(old('student_role')); ?>"><br>
            <textarea class="form-control" name="student_address" id=""><?php echo e(old('student_address')); ?></textarea><br>
            <input type="submit" class="btn btn-info" value="Submit">
        </form>
        </div>

        <div class="col-sm-6">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="text-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students_app/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>