<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.head-nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- <?php echo $__env->yieldContent('alert'); ?> -->
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="alert alert-danger"><strong>Failure!!!</strong> <?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(session()->has('success')): ?>
        <p class="alert alert-success"><strong>Success!!!</strong> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    <?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <form action="<?php echo e(route('cat.store')); ?>" method="post" id="formsend">
        <?php echo e(csrf_field()); ?>

        <label for="cat_name" class="sr-only">Category name</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="<?php echo e(old('title')); ?>" name="cat_name"><br>
        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Create Category</button>
      </form><br>
      <div class="panel panel-default">
      <!-- Default panel contents -->
      <div class="panel-heading">Categories</div>

      <!-- Table -->
      <table class="table">
        <thead>
          <tr>
            <!-- <th>#</th> -->
            <th>Category title</th>
            <th>Added by</th>
            <th colspan="2">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($cats->cat_name); ?></td>
            <td><?php echo e($added_by->username); ?></td>
            <td colspan="2"><a href="<?php echo e(url('/cat')); ?>/<?php echo e($cats->id); ?>/edit" class="btn btn-info">Edit</a>
            <form action="<?php echo e(route('cat.destroy',$cats->id)); ?>" method="post" style="display:inline;">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="_method" value="DELETE">
                <button type="submit" class="btn btn-danger" title="Delete category">del</button>
            </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </main>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>