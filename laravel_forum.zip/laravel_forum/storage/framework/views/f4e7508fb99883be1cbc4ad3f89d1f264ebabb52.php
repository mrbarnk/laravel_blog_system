
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- <?php echo $__env->yieldContent('alert'); ?> -->
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="alert alert-danger"><strong>Failure!!!</strong> <?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(session()->has('success')): ?>
        <p class="alert alert-success"><strong>Success!!!</strong> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    <?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <form action="<?php echo e(route('postroute.store')); ?>" method="post" id="formsend">
        <?php echo e(csrf_field()); ?>

        <label for="inputTitle" class="sr-only">Title</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="<?php echo e(old('title')); ?>" name="title"><br>
        <label for="category" class="sr-only"></label>
        <select name="status" id="" class="form-control" style="height:40px;">
            <option value="0" selected>Visible</option>
            <option value="1">Draft(will not be in news feed)</option>
        </select><br>
        <label for="category" class="sr-only"></label>
        <select name="category" id="" class="form-control" style="height:40px;">
        <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cats->id); ?>"><?php echo e($cats->cat_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
        <label for="message" class="sr-only">Message</label>
        <textarea id="txtEditor" name="message" cols="30" rows="10" class="form-control"><?php echo e(old('message')); ?></textarea><br>
        <!-- <input type="text" class="form-control"><br> -->
        <?php if(session()->get('user_role') == 7): ?>
        <p>Pin To Homepage</p>
        <select name="is_pinned" id="" class="form-control" style="height:40px;">
            <option value="no">No</option>
            <option value="yes">Yes</option>
        </select><br>
        <p>Dissable comment</p>
        <select name="dissable_comment" id="" class="form-control" style="height:40px;">
            <option value="no">No</option>
            <option value="yes">Yes</option>
        </select><br>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Create Post</button>
      </form>
    </main>
  