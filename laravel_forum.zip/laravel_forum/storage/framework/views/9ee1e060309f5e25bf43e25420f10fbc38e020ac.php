<?php $__env->startSection('title'); ?>
    Student Enrollement App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<br class="clearfix" style="clear:both!important;">
<h1>Our Content</h1>

<?php if(session()->has('success')): ?>
   <p class="alert alert-success" role="alert"> <?php echo e(session()->get('success')); ?> </p>
<?php endif; ?>

<div class="col-sm-12">
        <div class="col-sm-6">
        <div class="panel panel-default">
            <!-- Default panel contents -->
            <!-- Table -->
            <table class="table"> 
            <tr>
                <th>#</th>
                <th>Student name</th>
                <th>Student role</th>
                <th>Student Address</th>
                <th>Action</th>
            </tr>
            <?php $i =0; ?>

                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i=$i+1; ?>
                <tr>
                    <td> <?php echo e($i); ?> </td>
                    <td><?php echo e($studs->student_name); ?></td>
                    <td><?php echo e($studs->student_role); ?></td>
                    <td><?php echo e($studs->student_address); ?></td>
                    <td colspan="2"> 
                        <a href="<?php echo e(url('/')); ?>/<?php echo e($studs->id); ?>/edit">Edit</a> || <a href="#">Delete</a>
                    </td>
                <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students_app/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>