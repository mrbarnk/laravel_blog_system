<body>

    <div class="container">
<?php if(session()->has('success')): ?>
<p class="alert alert-success"><strong>Success!</strong> <?php echo e(session()->get('success')); ?>.</p>
<?php endif; ?>
<?php if(session()->has('failure')): ?>
<p class="alert alert-danger"><strong>Success!</strong> <?php echo e(session()->get('failure')); ?>.</p>
<?php endif; ?>
<!-- <p class="alert alert-danger"><strong>Success!</strong> signup not successful.</p> -->
<div class="col-sm-12 panel">
        <h2 class="form-signin-heading text-center">Please sign up</h2><hr>
<div class="col-sm-6">
<form class="form-signin" action="<?php echo e(route('user.store')); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

        <label for="inputUsername" class="sr-only">Username</label>
        <input type="text" id="inputUsername" class="form-control" placeholder="Username" autofocus value="<?php echo e(old('username')); ?>" name="username"><br>
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" autofocus value="<?php echo e(old('email')); ?>" name="email"><br>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password"><br>
        <div class="checkbox hide">
          <label>
            <input type="checkbox" value="remember-me"> Remember me
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
      </form>
</div>
<div class="col-sm-6">
<h5>Errors</h5>
<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="alert alert-danger"><?php echo e($error); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
</div>
</div>
    </div> <!-- /container -->
<style>
body {
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #eee;
}

.form-signin {
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  height: auto;
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}</style>

  </body>