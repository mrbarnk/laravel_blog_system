<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.head-nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Begin page content -->
    <main role="main" class="container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-12">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/user')); ?>/<?php echo e($post->author); ?>/edit" class="btn btn-info">Edit account</a>
    </div><br>
    <div class="col-sm-8 text-center" style="">
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p class="alert alert-danger"><?php echo e($error); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(session()->has('failure')): ?>
      <p class="alert alert-danger"><?php echo e(session()->get('failure')); ?></p>
    <?php endif; ?>
    </div>

      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    <?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <table class="table">
        <thead class="thead-light">
          <tr>
            <th scope="col">Topic</th>
            <th scope="col">Created</th>
            <th scope="col">Statistic</th>
            <th>Last post</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $safeUrl = strtolower(str_replace(' ','-',$post->title)); ?>
          <tr>
            <td><a href="<?php echo e(url('/t')); ?>/<?php echo e($post->id.'/'.$safeUrl); ?>"> <span class="btn btn-info"><i class="glyphicon glyphicon-pushpin"></i> </span> <?php echo e($post->title); ?></a></td>
            <td>by <a href="<?php echo e(url('/')); ?>/u/<?php echo e($post_user->username); ?>"><?php echo e($post_user->username); ?></a><br> <?php echo e($post->created_at); ?> </td>
            <td><!--5 replies--><i class="glyphicon glyphicon-eye-open"></i> <br /><?php echo e($post->views); ?> views</td>
            <td>by <a href="<?php echo e(url('/')); ?>/u/<?php echo e($post_user->username); ?>"><?php echo e($post_user->username); ?></a><br /><?php echo e($post->created_at); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <hr>
                <?php if($paginator->hasPages()): ?>
                <ul class="pagination" role="navigation">
                    
                    <?php if($paginator->onFirstPage()): ?>
                        <li class="disabled" aria-disabled="true"><span><?php echo app('translator')->getFromJson('pagination.previous'); ?></span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo app('translator')->getFromJson('pagination.previous'); ?></a></li>
                    <?php endif; ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo app('translator')->getFromJson('pagination.next'); ?></a></li>
                    <?php else: ?>
                        <li class="disabled" aria-disabled="true"><span><?php echo app('translator')->getFromJson('pagination.next'); ?></span></li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
    </main>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>