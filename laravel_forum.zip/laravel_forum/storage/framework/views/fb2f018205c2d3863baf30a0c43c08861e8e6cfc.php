<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.head-nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Begin page content -->
    <main role="main" class="container">
    <!-- <?php echo $__env->yieldContent('alert'); ?> -->
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="alert alert-danger"><strong>Failure!!!</strong> <?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(session()->has('success')): ?>
        <p class="alert alert-success"><strong>Success!!!</strong> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
      <!-- <h1 class="mt-5">Sticky footer with fixed navbar</h1> -->
    <?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <form action="<?php echo e(route('cat.update',$cats->id)); ?>" method="post" id="formsend">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="token_" value="<?php echo e($cats->id); ?><?php echo uniqid().rand(0,10); ?>">
        <label for="cat_name" class="sr-only">Category name</label>
        <input type="text" id="inputTitle" class="form-control" placeholder="Title" autofocus value="<?php echo e($cats->cat_name); ?>" name="cat_name"><br>
        <!-- <input type="text" class="form-control"><br> -->
        <button type="submit" class="btn btn-primary">Update Category</button>
      </form>
    </main>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>