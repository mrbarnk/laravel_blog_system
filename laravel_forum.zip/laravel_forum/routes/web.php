<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::view('/','welcome');
Route::resource('/user','Users');
Route::get('/u/{name}','Users@showUserPost');
Route::get('/','Posts@index');
Route::view('/register','register');
Route::post('/login','Users@login');
Route::get('/new-post','Posts@new_post');
Route::get('/logout','Users@logout');
Route::resource('/postroute','Posts');
Route::get('/post/{id}/edit','Posts@edit');
Route::get('/t/{id}/{name}','Posts@show');
// Route::view('/createcat','categories');
Route::resource('cat','Categories');
Route::get('c/{name}','Categories@show');
// Route::get('/page/{name}','Posts@index');
Route::get('/page/{id}','Posts@page');
Route::resource('comment','Comments');
//mail
Route::get('sendbasicemail','MailController@basic_email');
Route::get('sendhtmlemail','MailController@html_email');
Route::get('sendattachmentemail','MailController@attachment_email');

// Route::view('/createcat/{id}/edit','edit-categories');
// Route::view('/createstuds','create_student');
// Route::get('/getstudent','StudentController@index');
// Route::get()
// Route::get('/',function () {
//     return view('show_student');
// // });
// Route::resource('student','StudentController');
// Route::get('{id}/edit','StudentController@edit');